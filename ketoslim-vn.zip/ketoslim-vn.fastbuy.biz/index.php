<!DOCTYPE html>
<!-- saved from url=(0028)https://www.ketoslim.com.vn/ -->
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>KETO SLIM - MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI BẠN CHƯA BAO GIỜ BIẾT TỚI</title>
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Keto Slim, Keto, Giảm Cân, Giảm Béo">
    <meta name="description" content="KETO SLIM - MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI BẠN CHƯA BAO GIỜ BIẾT TỚI">
    <script id="script_viewport" type="text/javascript">
    	function ladiViewport() {
	        var width = (window.outerWidth > 0) ? window.outerWidth : screen.width;
	        var content = "user-scalable=no";
	        if (width < 580) {
	            content += ", width=414";
	        }
	        var meta = document.querySelector('meta[name="viewport"]');
	        if (meta == undefined) {
	            meta = document.createElement('meta');
	            meta.name = 'viewport';
	            document.head.prepend(meta);
	        }
	        meta.content = content;
	    };
	    ladiViewport();
	</script>
    <meta property="og:title" content="KETO SLIM - MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI BẠN CHƯA BAO GIỜ BIẾT TỚI">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://i.imgur.com/K68V1P6.png">
    <meta property="og:description" content="KETO SLIM - MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI BẠN CHƯA BAO GIỜ BIẾT TỚI">
    <meta name="format-detection" content="telephone=no">
    <link rel="shortcut icon" type="image/png" href="https://i.imgur.com/K68V1P6.png">
    <link rel="dns-prefetch">
    <link rel="preconnect" href="https://fonts.googleapis.com/" crossorigin="">
    <link rel="stylesheet" type="text/css" href="./assets/css/font.css">
    <link rel="stylesheet" type="text/css" href="./assets/css/style.css?ver=5.1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<!-- Hotjar Tracking Code for https://eway.vn -->
	<script>
		(function(h,o,t,j,a,r){
		h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
		h._hjSettings={hjid:1029235,hjsv:6};
		a=o.getElementsByTagName('head')[0];
		r=o.createElement('script');r.async=1;
		r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
		a.appendChild(r);
		})(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
	</script>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-N7WXPN8');
    </script>
</head>
<body>
	<noscript>
	    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N7WXPN8" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
    <div id="SECTION1" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <!-- <div id="IMAGE390" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div> -->
            <div id="IMAGE8" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="HEADLINE14" class="ladi-element"><h3 class="ladi-headline">KETO LÀ GÌ?</h3></div>
            <div id="LINE15" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="PARAGRAPH16" class="ladi-element"><p class="ladi-paragraph">Keto là phương pháp dinh dưỡng giảm cân
                    chuẩn mực nổi tiếng trên thế giới đến từ Nhật. Chế độ ăn kiêng Keto luôn được các nghiên cứu đánh
                    giá cao về việc giảm thiểu cân nặng một cách đáng kể và giúp cải thiện sức khoẻ.<br></p></div>
            <div id="PARAGRAPH272" class="ladi-element"><p class="ladi-paragraph">Chế độ ăn Ketogenic (keto) là một chế
                    độ ăn ít carb, nhiều chất béo. Nó làm giảm lượng đường và insulin trong máu, và khiến cơ chế trao
                    đổi chất của cơ thể chuyển từ carb sang chất béo và các xeton.<br></p></div>
            <div id="PARAGRAPH273" class="ladi-element"><p class="ladi-paragraph">Phó Viện Trưởng Viện Dinh Dưỡng Quốc
                    Gia Nguyễn Thị Lâm cho biết chế độ ăn KETO này rất tốt cho sức khỏe, tuy nhiên lại chứa một số tác
                    dụng phụ nhất định như khiến cơ thể mệt mỏi hoặc dễ tăng cân lại nếu bạn không nghiêm khắc theo đúng
                    quy trình ăn.<br></p></div>
            <div id="PARAGRAPH284" class="ladi-element"><p class="ladi-paragraph">MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI<br>BẠN
                    CHƯA BAO GIỜ BIẾT TỚI ĐẾN TỪ NHẬT BẢN<br></p></div>
            <div id="BOX288" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE289" class="ladi-element">
                <h3 class="ladi-headline">LẦN ĐẦU TIÊN CÓ MẶT TẠI VIỆT NAM<br>KHÔNG
                    CẦN ĂN KIÊNG HAY TẬP THỂ DỤC<br></h3>
            </div>
            <div data-scroll="#BOX181" id="IMAGE290" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            
            <div id="IMAGE411" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE413" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE415" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE416" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE417" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="LINE418" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="LINE419" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="IMAGE422" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="HEADLINE484" class="ladi-element"><h3 class="ladi-headline"><span
                            style="text-decoration-line: underline;">GIẢM 5-7KG SAU CHỈ 1 LIỆU TRÌNH<br></span>KHÔNG CẦN
                    ĂN KIÊNG HAY TẬP THỂ DỤC<br></h3>
                <div class="box-combo">
                    <h4>Mua 2 tặng 1 combo quà tặng cực giá trị bao gồm:</h4>
                    <ul>
                        <li>1 lọ Keto Slim</li>
                        <li>1 cẩm nang khỏe đẹp: 7 ngày giảm cân tự nhiên với phương pháp Keto</li>
                        <li>Free ship toàn quốc</li>    
                    <ul>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION22" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE25" class="ladi-element"><h3 class="ladi-headline">VIÊN SỦI KETO SLIM RA ĐỜI ĐỂ LOẠI TRỪ
                    CÁC TÁC DỤNG PHỤ CỦA CỦA CHẾ ĐỘ ĂN NÀY<br></h3></div>
            <div id="LINE27" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="IMAGE135" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH298" class="ladi-element"><p class="ladi-paragraph">Ngay cả khi bạn không áp dụng chế độ
                    ăn KETO, sản phẩm này vẫn có thể giúp bạn giảm cân 5-7kg một cách thần kỳ!<br></p></div>
            <div id="PARAGRAPH301" class="ladi-element"><p class="ladi-paragraph">KETO SLIM&nbsp;<span
                            style="font-weight: bold;">HIỆU QUẢ GẤP 90 LẦN PHƯƠNG PHÁP KETO</span><br></p></div>
            <div data-scroll="#BOX181" id="IMAGE303" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="LIST_PARAGRAPH344" class="ladi-element">
                <div class="ladi-list-paragraph">
                    <ul>
                        <li class="">Ngăn chặn hấp thu tinh bột</li>
                        <li class="">Tăng cường chuyển hóa và đốt cháy mỡ thừa</li>
                        <li class="">Giúp cơ thể không cần sản sinh isulin</li>
                        <li class="">Không có isulin, bạn sẽ không còn cảm giác đói</li>
                    </ul>
                </div>
            </div>
            <div id="IMAGE392" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION127" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="IMAGE423" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE424" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION2" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE36" class="ladi-element"><h3 class="ladi-headline">VIÊN SỦI KETO SLIM ĐƯỢC BÀO CHẾ TỪ 100%
                    THIÊN NHIÊN, AN TOÀN TUYỆT ĐỐI, KHÔNG LO TÁC DỤNG PHỤ<br></h3></div>
            <div id="LINE37" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="GROUP62" class="ladi-element">
                <div class="ladi-group">
                    <div id="HEADLINE63" class="ladi-element"><h3 class="ladi-headline"><span
                                    style="font-weight: bold;">Glucomannan</span></h3></div>
                    <div id="PARAGRAPH64" class="ladi-element"><p class="ladi-paragraph">Thúc đẩy quá trình giảm béo, hạ
                            mỡ máu<br></p></div>
                </div>
            </div>
            <div id="GROUP65" class="ladi-element">
                <div class="ladi-group">
                    <div id="HEADLINE66" class="ladi-element"><h3 class="ladi-headline"><span
                                    style="font-weight: bold;">Chitosan</span></h3></div>
                    <div id="PARAGRAPH67" class="ladi-element"><p class="ladi-paragraph">Như một "nam châm" hút các axit
                            béo tại ruột và loại trừ khỏi cơ thể.<br></p></div>
                </div>
            </div>
            <div id="GROUP70" class="ladi-element">
                <div class="ladi-group">
                    <div id="IMAGE71" class="ladi-element">
                        <div class="ladi-image">
                            <div class="ladi-image-background"></div>
                        </div>
                    </div>
                    <div id="IMAGE72" class="ladi-element">
                        <div class="ladi-image">
                            <div class="ladi-image-background"></div>
                        </div>
                    </div>
                    <div id="IMAGE73" class="ladi-element">
                        <div class="ladi-image">
                            <div class="ladi-image-background"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="HEADLINE42" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">TRÀ TRẮNG</span>
                </h3></div>
            <div id="PARAGRAPH43" class="ladi-element"><p class="ladi-paragraph">Giảm thiểu các tế bào mỡ Adipogenesis,
                    tăng tốc độ trao đổi chất trong cơ thể</p></div>
            <div id="HEADLINE44" class="ladi-element"><h3 class="ladi-headline"><span
                            style="font-weight: bold;">TRÀ ĐEN</span></h3></div>
            <div id="PARAGRAPH45" class="ladi-element"><p class="ladi-paragraph">Chứa polyphenol, có khả năng đốt cháy
                    chất béo cực mạnh.<br></p></div>
            <div id="HEADLINE48" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">TRÀ XANH</span>
                </h3></div>
            <div id="PARAGRAPH49" class="ladi-element"><p class="ladi-paragraph">Chứa EGCG đốt cháy mỡ thừa, chuyển hóa
                    glucose, thanh lọc cơ thể.<br></p></div>
            <div id="IMAGE87" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                    <div class="ladi-overlay"></div>
                </div>
            </div>
            <div id="IMAGE88" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE89" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE90" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE91" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                    <div class="ladi-overlay"></div>
                </div>
            </div>
            <div id="GROUP150" class="ladi-element">
                <div class="ladi-group">
                    <div id="HEADLINE151" class="ladi-element"><h3 class="ladi-headline"><span
                                    style="font-weight: bold;">L-Glutamine</span></h3></div>
                    <div id="PARAGRAPH152" class="ladi-element"><p class="ladi-paragraph">Cung cấp năng lượng và giúp
                            duy trì sự tập trung, cũng như thúc đẩy giảm cân mà không làm mất khối lượng cơ bắp.<br></p>
                    </div>
                </div>
            </div>
            <div id="IMAGE207" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE208" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE209" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div data-scroll="#BOX181" id="IMAGE306" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION74" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="BOX479" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE128" class="ladi-element"><h3 class="ladi-headline">Hoà tan 1 viên với 100 - 150ml
                    nước</h3></div>
            <div id="HEADLINE129" class="ladi-element"><h3 class="ladi-headline">Uống trước bữa ăn 45 phút, mỗi ngày 2
                    lần</h3></div>
            <div id="HEADLINE130" class="ladi-element"><h3 class="ladi-headline">Dùng liên tục đến hết liệu trình</h3>
            </div>
            <div id="HEADLINE146" class="ladi-element"><h3 class="ladi-headline">KETO SLIM DÀNH CHO AI, DÙNG NHƯ THẾ
                    NÀO?<br></h3></div>
            <div id="LINE147" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="IMAGE155" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE156" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="IMAGE157" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div data-scroll="#BOX181" id="IMAGE432" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="BOX475" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="BOX476" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="BOX477" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="BOX478" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE480" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">Phụ nữ sau sinh nhiều mỡ thừa</span>
                </h3></div>
            <div id="HEADLINE481" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: 700;">Người thừa cân béo phì lâu năm</span><br>
                </h3></div>
            <div id="HEADLINE482" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: 700;">Những lười vận động&nbsp;</span><br>
                </h3></div>
            <div id="HEADLINE483" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: 700;">Người đang có nhu cầu giảm béo</span><br>
                </h3></div>
        </div>
    </div>
    <div id="SECTION35" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="BOX51" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE52" class="ladi-element"><h3 class="ladi-headline">Chuyên gia dinh dưỡng Nhật Bản nói về
                    Keto Slim</h3></div>
            <div id="LINE53" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="PARAGRAPH55" class="ladi-element"><p class="ladi-paragraph">Ông Yasumasa Hibi, Chuyên gia đầu
                    ngành với 10 năm kinh nghiệm trong vấn đề giảm cân đến từ Nhật Bản<br></p></div>
            <div id="IMAGE342" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH54" class="ladi-element"><p class="ladi-paragraph">Keto Slim là sản phẩm hỗ trợ giảm cân
                    dưới dạng viên sủi. Không chỉ phát huy những lợi ích tuyệt vời của chế độ ăn ketogenic như ổn định
                    lượng đường huyết trong máu, tăng cường chuyển hóa, đẩy nhanh tốc độ đốt cháy mỡ thừa.<br><br>Keto
                    Slim còn khắc phục những nhược điểm của phương pháp Keto bằng cách tăng cường sức khỏe, giảm cảm
                    giác thèm ăn nhằm duy trì hiệu quả giảm cân lâu dài.<br></p></div>
        </div>
    </div>
    <div id="SECTION368" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE369" class="ladi-element"><h3 class="ladi-headline">KETO SLIM ĐẠT CHUẨN GMP ĐƯỢC BỘ Y TẾ
                    <br>VÀ CỤC AN TOÀN THỰC PHẨM CẤP PHÉP<br></h3></div>
            <div id="LINE370" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="IMAGE388" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION214" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE219" class="ladi-element"><h3 class="ladi-headline">THỜI SỰ VTV1 ĐƯA TIN<br>VIÊN SỦI HỖ TRỢ
                    GIẢM BÉO KETO SLIM<br></h3></div>

            <div id="HTML_CODE367" class="ladi-element">
                <div class="ladi-video">
                    <div class="ladi-video-background"></div>
                    <div id="SHAPE447" class="ladi-element">
                        <div class="ladi-shape"><svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%"
                                preserveAspectRatio="none" viewBox="0 0 68 48" fill="#ff0000">
                                <path
                                    d="M66.52,7.74c-0.78-2.93-2.49-5.41-5.42-6.19C55.79,.13,34,0,34,0S12.21,.13,6.9,1.55 C3.97,2.33,2.27,4.81,1.48,7.74C0.06,13.05,0,24,0,24s0.06,10.95,1.48,16.26c0.78,2.93,2.49,5.41,5.42,6.19 C12.21,47.87,34,48,34,48s21.79-0.13,27.1-1.55c2.93-0.78,4.64-3.26,5.42-6.19C67.94,34.95,68,24,68,24S67.94,13.05,66.52,7.74z">
                                </path>
                                <path d="M 45,24 27,14 27,34" fill="#fff"></path>
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION58" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE158" class="ladi-element"><h3 class="ladi-headline">TRUYỀN THÔNG RẦM RỘ ĐƯA TIN VỀ KETO
                    SLIM<br></h3></div>
            <div id="LINE159" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="HEADLINE213" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">THỜI SỰ HTV9 ĐƯA TIN VỀ VIÊN SỦI KETO SLIM</span>
                </h3></div>
            <div id="HTML_CODE366" class="ladi-element">
                <div class="ladi-html-code">
                    <iframe width="400px" height="220" src="https://www.youtube.com/embed/mMp7cVs-fjs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            <div data-scroll="#BOX181" id="IMAGE433" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION404" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE405" class="ladi-element"><h3 class="ladi-headline">BÁO CHÍ ĐƯA TIN VỀ KETO SLIM<br></h3>
            </div>
            <div id="LINE406" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="IMAGE409" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION425" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="BOX426" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE427" class="ladi-element"><h3 class="ladi-headline">Chuyên gia nói về Keto Slim</h3></div>
            <div id="LINE428" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="PARAGRAPH429" class="ladi-element"><p class="ladi-paragraph">GS.TS Đào Văn Phan, Trưởng Bộ Môn Dược
                    Lý Đại Học Y Hà Nội<br></p></div>
            <div id="IMAGE430" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH431" class="ladi-element"><p class="ladi-paragraph">"Chế độ ăn keto có ưu điểm giúp giảm
                    mỡ toàn thân, chống các bệnh tim mạch, ung thư, kể cả khi không vận động. Tuy nhiên, đối với cơ địa
                    không phù hợp, áp dụng dễ khiến cơ thể suy kiệt, dễ mắc bệnh.<br><br>Viên sủi Keto Slim ra đời giúp
                    hoàn thiện phương pháp Keto. Tinh chất 3 loại trà đẩy mạnh trao đổi chất, kết hợp lại trong viên sủi&nbsp;
                    Keto làm tăng hiệu quả hấp thu gấp 5 lần các phương pháp khác giúp đẩy nhanh quá trình ketosis, hiệu
                    quả gấp 90 lần phương pháp keto. Do vậy, việc giảm béo trở nên đơn giản, hiệu quả và không gây hại
                    cho cơ thể."<br></p></div>
            <div data-scroll="#BOX181" id="IMAGE434" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
        </div>
    </div>
    <div id="SECTION247" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-container">
            <div id="HEADLINE249" class="ladi-element"><h3 class="ladi-headline">CẢM NHẬN KHÁCH HÀNG<br>SAU KHI SỬ DỤNG
                    KETO SLIM<br></h3></div>
            <div id="LINE250" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="BOX251" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="IMAGE252" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH253" class="ladi-element"><p class="ladi-paragraph">Tôi đã giảm 4 kg sau hơn 1 tuần
                    uống Keto Slim và tập luyện. Tôi bị béo từ hồi sinh viên, hiện tại đã ra trường nhưng vì
                    ngoại hình béo khó xin việc. Tôi kết hợp tập luyện ăn kiêng nhưng không hiệu quả, chỉ thấy
                    người ngày càng mệt do mất sức. nhờ anh bạn bên Mỹ chỉ cho phương pháp Keto và sản phẩm Keto
                    Slim, tôi đã giảm cân thành công. Tôi kết hợp sử dụng Keto Slim và tập luyện nhẹ nhàng, tôi
                    thấy cơ thể khỏe hơn nhiều. Chúc các bạn thành công, hãy kiên trì nhé!</p></div>
            <div id="PARAGRAPH254" class="ladi-element"><p class="ladi-paragraph">Vân Trang (26 tuổi) -&nbsp;Thái
                    Bình</p></div>
            <div id="BOX255" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="PARAGRAPH256" class="ladi-element"><p class="ladi-paragraph">Đến tuổi này người tôi ngày càng sồ
                    sề nên tôi thấy rất khó chịu. Dù mỗi ngày nhịn ăn hay ban đêm tôi chỉ ăn rau thôi cũng không
                    giảm được cân nào. Tôi có tham gia lớp khiêu vũ tuổi trung niên nên nếu thân hình xấu tôi cũng
                    thấy ngại lắm. Bà bạn tôi về hỏi con gái thì thấy con đang dùng viên sủi Keto Slim để giảm
                    cân, thế hai chúng tôi cùng đua nhau dùng. Thế mà giảm được 5kg mỡ bụng đấy. Cứ pha mỗi
                    ngày 1 viên, tôi uống đến lọ thứ 2 thấy vùng mỡ bụng với bắp tay giảm hẳn. Nhưng tôi cắt
                    hẳn cơm, chỉ ăn thịt và rau thôi. Nhưng nhìn thân hình như thế này tôi cũng thấy xứng
                    đáng.</p></div>
            <div id="IMAGE257" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH258" class="ladi-element"><p class="ladi-paragraph">Hoàng Trinh (38 tuổi) - Hà Nội</p>
            </div>
            <div id="BOX259" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="IMAGE260" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="PARAGRAPH261" class="ladi-element"><p class="ladi-paragraph">Sau khi sinh cháu đầu tiên, cơ thể
                    mình tăng cân không kiểm soát, thực sự rất nặng nề. Vì mình còn phải giữ sức nuôi con, không
                    thể nhịn ăn hay tập luyện cường độ cao được nên phải tìm nhũng phương pháp khác. Sau khi tìm
                    hiểu, mình biết đến phương pháp Keto và thấy rất hứng thú vì vừa giảm cân lại tốt cho sức
                    khỏe, tuy nhiên rất khó để thực hiện và khá lằng nhằng.&nbsp; Keto Slim dạng viên sủi vị dễ
                    uống như mấy viên C sủi thôi, mình vẫn ăn uống bình thường, chỉ giảm tinh bột. Sau 2 tuần
                    mình giảm được 4kg mà không hề thấy mệt mỏi. Cảm ơn Keto Slim rất nhiều.</p></div>
            <div id="PARAGRAPH262" class="ladi-element"><p class="ladi-paragraph">Thu Hương (31 tuổi) - Hồ Chí Minh</p>
            </div>
            <!-- <div id="BOX304" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div> -->
           <!--  <div id="PARAGRAPH305" class="ladi-element"><p class="ladi-paragraph">Đây là một phương pháp mà Tú Anh nghĩ rằng phải có ai quyết tâm và kiên trì thì mới theo được và Tú Anh đã hoàn toàn thất bại rất nhiều lần.<br>Nhưng mà rất may sau nhiều lần thử nghiệm, Tú Anh cũng đã lấy lại được vóc dáng mơ ước của mình.</p></div>
            <div id="PARAGRAPH340" class="ladi-element"><p class="ladi-paragraph">Hoa hậu Tú Anh - Á hậu 1 Hoa hậu Việt
                    Nam 2012</p></div>
            <div id="IMAGE343" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div> -->
        </div>
    </div>
    <div id="SECTION176" class="ladi-section">
        <div class="ladi-section-background"></div>
        <div class="ladi-overlay"></div>
        <div class="ladi-container">
            <div id="BOX307" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE177" class="ladi-element"><h3 class="ladi-headline">CÒN CHẦN CHỪ GÌ NỮA MÀ BẠN CHƯA GIẢM
                    5-7KG CÙNG VỚI KETO SLIM NGAY HÔM NAY?</h3></div>
            <div id="IMAGE178" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="HEADLINE179" class="ladi-element"><h3 class="ladi-headline">MỘT PHƯƠNG PHÁP GIẢM CÂN TUYỆT VỜI MÀ
                    BẠN CHƯA TỪNG BIẾT TỚI!</h3></div>
            <div id="BOX181" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="BOX183" class="ladi-element">
                <div class="ladi-box"></div>
                <div class="ladi-overlay"></div>
            </div>
            <div id="HEADLINE184" class="ladi-element"><h3 class="ladi-headline">HÃY LÀ 100 NGƯỜI ĐẦU TIÊN</h3></div>
            <div id="HEADLINE185" class="ladi-element"><h3 class="ladi-headline">NHẬN ƯU ĐÃI MUA 2 TẶNG 1</h3></div>
            <div id="COUNTDOWN187" class="ladi-element" data-type="countdown" data-minute="104" data-date-start="0"
                 data-date-end="1571113004495">
                <div class="ladi-countdown">
                    
                </div>
            </div>
            <div id="HEADLINE193" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">NGÀY&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;GIỜ&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; PHÚT&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; GIÂY</span>
                </h3></div>
            <div id="HEADLINE202" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">KHUYẾN MÃI HẤP DẪN</span>
                </h3></div>
            <div id="HEADLINE204" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">GIÁ GỐC: 1.580.000đ</span>
                </h3></div>
            <div id="HEADLINE205" class="ladi-element"><h3 class="ladi-headline"><span style="font-weight: bold;">*Chỉ áp dụng cho 100 người đầu tiên, số lượng có hạn</span>
                </h3></div>
            <div id="IMAGE180" class="ladi-element">
                <div class="ladi-image">
                    <div class="ladi-image-background"></div>
                </div>
            </div>
            <div id="HTML_CODE351" class="ladi-element">
                <div class="ladi-html-code">
                    <div id="getfly-optin-form-iframe-1569404097905">
                        <form id="getfly-form" class="getfly-form" action="order.php?fb_pixel_id=<?php echo (string)htmlspecialchars(@$_GET['fb_pixel_id'], ENT_QUOTES, 'utf-8'); ?>" method="POST">	
                        	<input type="hidden" name="click_id" value="<?php echo (string)@$_GET['click_id']; ?>">
				            <input type="hidden" name="address" value="">
				            <input type="hidden" name="adf_source" value="">
				            <input type="hidden" name="country_code" value="VN">
				            <input type="hidden" name="ip_country" value="VN">		
                        	<div class="getfly-row">					
                        		<input type="text" class="getfly-input " name="name" placeholder="Họ tên *">				
                        	</div>			
                        	<div class="getfly-row">		
                       			<input type="tel" name="phone" class="getfly-input " placeholder="Số điện thoại *">				
                       		</div>			
                       		<div class="getfly-row">		
                       			<input type="text" class="getfly-input " name="address" placeholder="Địa chỉ nhận hàng">				
                       		</div>				
                       		<div class="getfly-mt10 getfly-btn">			
                       			<a class="getfly-button getfly-button-bg js_submit">MUA HÀNG NGAY</a>		
                       		</div>	
                       	</form>
                    </div>
                </div>
            </div>
            <div id="LINE353" class="ladi-element">
                <div class="ladi-line">
                    <div class="ladi-line-container"></div>
                </div>
            </div>
            <div id="HEADLINE358" class="ladi-element"><h3 class="ladi-headline">CHỈ CÒN</h3></div>
            <div id="HEADLINE359" class="ladi-element"><h3 class="ladi-headline">790.000đ/HỘP</h3></div>
        </div>
    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.rawgit.com/hilios/jQuery.countdown/2.2.0/dist/jquery.countdown.min.js"></script>
<script>
	var setTimer = moment().add(1, 'hours').add(12,'minutes').format('YYYY/MM/DD HH:mm:ss');
	$('.ladi-countdown').countdown(setTimer, function(event) {
		 $(this).html(event.strftime('<div id="COUNTDOWN_ITEM188" class="ladi-element"><div class="ladi-countdown-text"><span>%d</span></div></div><div id="COUNTDOWN_ITEM188" class="ladi-element"><div class="ladi-countdown-text"><span>%H</span></div></div><div id="COUNTDOWN_ITEM188" class="ladi-element"><div class="ladi-countdown-text"><span>%M</span></div></div><div id="COUNTDOWN_ITEM188" class="ladi-element"><div class="ladi-countdown-text"><span>%S</span></div></div>')
		);
		$('span#hour').html(`${event.strftime('%-H')}`)
		$('span#minute').html(`${event.strftime('%-M')}`)
		$('span#seconds').html(event.strftime('%-S'))
	});
</script>
<!-- Cookie-popup-wrap -->
<div class="cookie-popup-wrap">
    <div class="cookie-popup">
        <h2>Để lại thông tin để được mua hàng với giá ưu đãi</h2>
        <form action="order.php?fb_pixel_id=<?php echo (string)htmlspecialchars(@$_GET['fb_pixel_id'], ENT_QUOTES, 'utf-8'); ?>" method="POST" role="form" class="form-order">
            <input type="hidden" name="click_id" value="<?php echo (string)@$_GET['click_id']; ?>">
            <input type="hidden" name="address" value="">
            <input type="hidden" name="adf_source" value="">
            <input type="hidden" name="country_code" value="VN">
            <input type="hidden" name="ip_country" value="VN">
            <div class="content">
                <div class="form-group">
                    <label for="">Họ tên *</label>
                    <input type="text" class="form-control" id="name" name="name">
                </div>
                <div class="form-group">
                    <label for="">Số điện thoại *</label>
                    <input type="tel" class="form-control" id="phone" name="phone">
                </div>
                <!-- <div class="form-group">
                    <label for="">Địa chỉ</label>
                    <textarea class="form-control" placeholder="Địa chỉ" name="address" id="address" cols="30" rows="3" maxlength="255" style="height: auto"></textarea>
                </div> -->
                <button type="submit" class="btn btn-block btn-box js_submit">Đặt mua ngay</button>
            </div>
        </form>
        <h6 id="closepopup"><a href="#" style="color: #fff;font-weight: bold;">Đóng</a></h6>
    </div>
</div>
	
<!--End .cookie-popup-->
<style>
    div.cookie-popup-wrap {
        position: relative;
        width: 100%;
        height: 100%;
        position: fixed;
        background: rgba(0, 0, 0, 0.6);
        top: 0;
        left: 0;
        display: none;
        z-index: 99999;
        /*padding: 15px;*/
    }

    div.cookie-popup {
        font-family: "Roboto";
        max-width: 340px;
        margin: 10% auto;
        background-color: #323437;
        padding: 10px 20px;
        z-index: 1000;
        border: 2px solid #fed203;
        border-radius: 5px;
    }

    div.cookie-popup form {
        width: 100%;
        margin: 5% auto;
        background-color: #323437;
        padding: 0;
        border: none;
    }

    div.cookie-popup h2 {
        margin-bottom: 20px;
        font-size: 22px;
        text-align: center;
        color: #fff;
        text-transform: uppercase;
        line-height: 1.35;
    }

    div.cookie-popup .form-order .content{
        background-color: #323437;
    }

    div.cookie-popup p {
        text-align: right;
        font-size: 12px;
        margin-top: 20px;
        padding-top: 5px;
    }

    div.cookie-popup h6 a {
        color: #888;
        text-decoration: none;
    }

    div.cookie-popup h6 {
        border-top: 1px solid #DDDDDD;
        text-align: right;
        font-size: 12px;
        margin-top: 20px;
        padding-top: 10px;
    }

    div.cookie-popup h6 a {
        color: #888;
        text-decoration: none;
    }

    div.cookie-popup input {
        width: 100%;
        height: 35px;
        margin: 7px auto;
        text-indent: 5px;
        font-size: 15px;
        line-height: 35px;
        font-family: "RobotoRegular", sans-serif;
        color: #8b8b8b;
        background-color: #ffffff;
        border: none;
        outline: none;
        display: block;
    }

    div.cookie-popup label {
        color: #fff;
        font-size: 17px;
        font-weight: normal;
        margin-bottom: unset;
    }

    div.cookie-popup .js_submit {
        text-align: center;
        color: #fff;
        font-size: 22px;
        margin-top: 5px;
        width: 100%;
        text-transform: uppercase;
        background: linear-gradient(to top,#b80630,#b80630);
    }

    div.cookie-popup .text-popup {
        display: block;
        width: 240px;
        margin: 15px auto;
        padding: 10px;
    }

    div.cookie-popup-wrap .cookie-popup .form-order .content {
        padding: 0;
        border: none;
    }

    </style>
    <!-- End.cookie-popup-wrap -->

<!-- Connect -->
<script type="text/javascript" src="https://d2uk0m3iwj5j1z.cloudfront.net/epage-1.8.6.js"></script>
<script type="text/javascript">

    Epage.init({
        offer_id: 'ketoslim-vn',
        hint_phone: '0164567890',
        hint_name: 'Lê Ngọc Minh',
        popup_time: 45000
    });
   
</script>

<script>
    $(function() {
        $('[data-scroll]').click(function() {
            var target = $(this).data('scroll');
            $('html,body').animate({
                scrollTop: $(target).offset().top
            }, 700);
            return false;
        });
    });

    $("#HTML_CODE367").click(function(){
            var id = $(this).attr('id');
            if(id === 'HTML_CODE367') token = '8LlezYfMH4s';
            $('iframe').remove();
            $(this).find('.ladi-video').append(`<iframe id="${id}_player" class="iframe-video-play" style="position: absolute; width: 100%; height: 100%; top: 0; left: 0;" src="https://www.youtube.com/embed/${token}?autoplay=1&rel=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`);

        })
</script>

<!-- FB Pixel -->
<?php
	$fbPixel = htmlspecialchars(@$_GET['fb_pixel_id'], ENT_QUOTES, 'utf-8');
	if (isset($fbPixel) && $fbPixel !== '') {
		echo "<script>
			!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
			n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
			n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
			t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
			document,'script','https://connect.facebook.net/en_US/fbevents.js');

			fbq('init', '$fbPixel');
			fbq('track', \"PageView\");
			</script>
			<noscript><img height=\"1\" width=\"1\" style=\"display:none\"
			src=\"https://www.facebook.com/tr?id=$fbPixel&ev=PageView&noscript=1\"
			/></noscript>";
	}
?>

<!-- Facebook Pixel Code -->
<script>
	!function(f,b,e,v,n,t,s)
	{if(f.fbq)return;n=f.fbq=function()

	{n.callMethod? n.callMethod.apply(n,arguments):n.queue.push(arguments)}
	;
	if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
	n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];
	s.parentNode.insertBefore(t,s)}(window, document,'script',
	'https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '583308888863647');
	fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=583308888863647&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->

<!-- Facebook Pixel2 Code -->
    <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function()

        {n.callMethod? n.callMethod.apply(n,arguments):n.queue.push(arguments)}
        ;
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '2420216824725112');
        fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
                   src="https://www.facebook.com/tr?id=2420216824725112&ev=PageView&noscript=1"
        /></noscript>
    <!-- End Facebook Pixel Code -->

</body>
</html>